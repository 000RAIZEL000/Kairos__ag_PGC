import os
from flask import Flask, jsonify, send_from_directory
from config import config
from extensions import db, migrate, cors

# ── importar modelos para que SQLAlchemy los registre ────────────────────────
from models.usuario import Usuario
from models.torneo   import Torneo
from models.equipo   import Equipo
from models.jugador  import Jugador
from models.partido  import Partido, Gol, Tarjeta, JugadorPartido

# ── importar blueprints ───────────────────────────────────────────────────────
from routes.auth         import auth_bp
from routes.torneos      import torneos_bp
from routes.equipos      import equipos_bp
from routes.jugadores    import jugadores_bp
from routes.partidos     import partidos_bp
from routes.tabla        import tabla_bp
from routes.estadisticas import estadisticas_bp


def create_app(env=None):
    app = Flask(__name__)

    # configuración
    env = env or os.getenv('FLASK_ENV', 'development')
    app.config.from_object(config.get(env, config['default']))

    # extensiones
    db.init_app(app)
    migrate.init_app(app, db)
    cors.init_app(app, resources={r"/api/*": {"origins": "*"}})

    # blueprints  →  todos bajo /api/
    app.register_blueprint(auth_bp,         url_prefix='/api/auth')
    app.register_blueprint(torneos_bp,      url_prefix='/api/torneos')
    app.register_blueprint(equipos_bp,      url_prefix='/api/equipos')
    app.register_blueprint(jugadores_bp,    url_prefix='/api/jugadores')
    app.register_blueprint(partidos_bp,     url_prefix='/api/partidos')
    app.register_blueprint(tabla_bp,        url_prefix='/api/tabla')
    app.register_blueprint(estadisticas_bp, url_prefix='/api/estadisticas')

    # health-check
    @app.route('/api/health')
    def health():
        return jsonify({'status': 'ok', 'app': 'Kairos AG'}), 200

    # ── Servir frontend estático ───────────────────────────────────────────────
    frontend_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'frontend')

    @app.route('/')
    def frontend_index():
        return send_from_directory(frontend_dir, 'index.html')

    @app.route('/<path:filename>')
    def frontend_static(filename):
        return send_from_directory(frontend_dir, filename)

    @app.route('/api/')
    def index():
        return jsonify({
            'app':     '🏆 Kairos AG – Eventos Deportivos',
            'version': '2.0',
            'docs':    '/api/health',
            'rutas': {
                'auth':         '/api/auth',
                'torneos':      '/api/torneos',
                'equipos':      '/api/equipos',
                'jugadores':    '/api/jugadores',
                'partidos':     '/api/partidos',
                'tabla':        '/api/tabla/<torneo_id>',
                'estadisticas': '/api/estadisticas/torneo/<torneo_id>',
            }
        })

    # crear tablas + seed admin
    with app.app_context():
        db.create_all()
        _seed_admin()

    return app


def _seed_admin():
    """Crea el admin por defecto si no existe."""
    if not Usuario.query.filter_by(email=os.getenv('ADMIN_EMAIL', 'admin@kairos.com')).first():
        admin = Usuario(
            nombre='Administrador', apellido='Kairos',
            email=os.getenv('ADMIN_EMAIL', 'admin@kairos.com'),
            telefono='', genero='otro', rol='admin'
        )
        admin.set_password(os.getenv('ADMIN_PASSWORD', 'admin123'))
        db.session.add(admin)
        db.session.commit()
        print('✅  Admin creado →', admin.email)


# gunicorn necesita `app` en el módulo raíz
app = create_app()

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    print(f'\n🏆  Kairos AG  →  http://localhost:{port}\n')
    app.run(host='0.0.0.0', port=port)
