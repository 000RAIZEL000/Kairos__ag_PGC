from flask import Blueprint, jsonify, request
from models.partido import Gol, Tarjeta, JugadorPartido, Partido
from models.jugador import Jugador
from models.equipo  import Equipo
from sqlalchemy import func
from extensions import db

estadisticas_bp = Blueprint('estadisticas', __name__)


# ── GET /api/estadisticas/goleadores/<torneo_id> ──────────────────────────────
@estadisticas_bp.route('/goleadores/<int:torneo_id>', methods=['GET'])
def goleadores(torneo_id):
    limite = request.args.get('limite', 10, type=int)
    rows = (
        db.session.query(
            Jugador.id, Jugador.nombre, Jugador.apellido, Jugador.foto_url,
            Equipo.nombre.label('equipo'),
            func.count(Gol.id).label('goles')
        )
        .join(Gol,    Gol.jugador_id == Jugador.id)
        .join(Equipo, Equipo.id      == Gol.equipo_id)
        .filter(Equipo.torneo_id == torneo_id)
        .group_by(Jugador.id)
        .order_by(func.count(Gol.id).desc())
        .limit(limite).all()
    )
    return jsonify([
        dict(pos=i, jugador_id=r.id, nombre=f'{r.nombre} {r.apellido}',
             foto=r.foto_url, equipo=r.equipo, goles=r.goles)
        for i, r in enumerate(rows, 1)
    ]), 200


# ── GET /api/estadisticas/tarjetas/<torneo_id> ────────────────────────────────
@estadisticas_bp.route('/tarjetas/<int:torneo_id>', methods=['GET'])
def tarjetas(torneo_id):
    limite = request.args.get('limite', 10, type=int)
    rows = (
        db.session.query(
            Jugador.id, Jugador.nombre, Jugador.apellido,
            Equipo.nombre.label('equipo'),
            func.sum(db.case((Tarjeta.tipo == 'Amarilla', 1), else_=0)).label('amarillas'),
            func.sum(db.case((Tarjeta.tipo == 'Roja',     1), else_=0)).label('rojas'),
            func.count(Tarjeta.id).label('total')
        )
        .join(Tarjeta, Tarjeta.jugador_id == Jugador.id)
        .join(Equipo,  Equipo.id          == Tarjeta.equipo_id)
        .filter(Equipo.torneo_id == torneo_id)
        .group_by(Jugador.id)
        .order_by(func.count(Tarjeta.id).desc())
        .limit(limite).all()
    )
    return jsonify([
        dict(jugador_id=r.id, nombre=f'{r.nombre} {r.apellido}', equipo=r.equipo,
             amarillas=int(r.amarillas), rojas=int(r.rojas), total=r.total)
        for r in rows
    ]), 200


# ── GET /api/estadisticas/torneo/<torneo_id> ──────────────────────────────────
@estadisticas_bp.route('/torneo/<int:torneo_id>', methods=['GET'])
def resumen_torneo(torneo_id):
    total      = Partido.query.filter_by(torneo_id=torneo_id).count()
    finalizados= Partido.query.filter_by(torneo_id=torneo_id, estado='Finalizado').count()
    goles      = (
        db.session.query(func.sum(Partido.goles_local + Partido.goles_visitante))
        .filter_by(torneo_id=torneo_id, estado='Finalizado').scalar() or 0
    )
    equipos    = Equipo.query.filter_by(torneo_id=torneo_id, activo=True).count()
    jugadores  = (
        db.session.query(func.count(Jugador.id))
        .join(Equipo, Equipo.id == Jugador.equipo_id)
        .filter(Equipo.torneo_id == torneo_id).scalar() or 0
    )
    return jsonify({
        'total_partidos':  total,
        'finalizados':     finalizados,
        'pendientes':      total - finalizados,
        'total_goles':     int(goles),
        'promedio_goles':  round(goles / finalizados, 2) if finalizados else 0,
        'total_equipos':   equipos,
        'total_jugadores': jugadores,
    }), 200


# ── GET /api/estadisticas/jugador/<jugador_id> ────────────────────────────────
@estadisticas_bp.route('/jugador/<int:jid>', methods=['GET'])
def stats_jugador(jid):
    j    = Jugador.query.get_or_404(jid)
    mins = (
        db.session.query(func.sum(JugadorPartido.minutos_jugados))
        .filter_by(jugador_id=jid).scalar() or 0
    )
    return jsonify({
        'jugador_id':   jid,
        'nombre':       f'{j.nombre} {j.apellido}',
        'posicion':     j.posicion,
        'equipo_id':    j.equipo_id,
        'goles':        j.goles.count(),
        'amarillas':    j.tarjetas.filter_by(tipo='Amarilla').count(),
        'rojas':        j.tarjetas.filter_by(tipo='Roja').count(),
        'partidos':     j.apariciones.count(),
        'min_jugados':  int(mins),
    }), 200


# ── GET /api/estadisticas/equipo/<equipo_id> ──────────────────────────────────
@estadisticas_bp.route('/equipo/<int:eid>', methods=['GET'])
def stats_equipo(eid):
    partidos = Partido.query.filter(
        (Partido.equipo_local_id == eid) | (Partido.equipo_visitante_id == eid),
        Partido.estado == 'Finalizado'
    ).all()

    pj = pg = pe = pp = gf = gc = 0
    for p in partidos:
        if p.equipo_local_id == eid:
            gl, gv = p.goles_local, p.goles_visitante
        else:
            gl, gv = p.goles_visitante, p.goles_local
        pj += 1; gf += gl; gc += gv
        if   gl > gv: pg += 1
        elif gl < gv: pp += 1
        else:         pe += 1

    return jsonify({
        'equipo_id': eid,
        'PJ': pj, 'PG': pg, 'PE': pe, 'PP': pp,
        'GF': gf, 'GC': gc, 'DG': gf - gc,
        'PTS': pg * 3 + pe,
    }), 200
