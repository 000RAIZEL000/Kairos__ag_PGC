from flask import Blueprint, request, jsonify, session
from models.torneo import Torneo
from extensions import db
from datetime import date

torneos_bp = Blueprint('torneos', __name__)

def _org():
    """Devuelve error si el usuario no es admin u organizador."""
    if session.get('rol') not in ('admin', 'organizador'):
        return jsonify({'error': 'Sin permisos'}), 403
    return None


# ── GET /api/torneos/ ──────────────────────────────────────────────────────────
@torneos_bp.route('/', methods=['GET'])
def listar():
    q = Torneo.query
    if request.args.get('estado'):
        q = q.filter_by(estado=request.args['estado'])
    if request.args.get('deporte'):
        q = q.filter(Torneo.deporte.ilike(f"%{request.args['deporte']}%"))
    torneos = q.order_by(Torneo.fecha_inicio.desc()).all()
    return jsonify([t.to_dict() for t in torneos]), 200


# ── GET /api/torneos/<id> ──────────────────────────────────────────────────────
@torneos_bp.route('/<int:tid>', methods=['GET'])
def detalle(tid):
    t = Torneo.query.get_or_404(tid)
    d = t.to_dict()
    d['total_equipos']  = t.equipos.count()
    d['total_partidos'] = t.partidos.count()
    d['partidos_jugados'] = t.partidos.filter_by(estado='Finalizado').count()
    return jsonify(d), 200


# ── POST /api/torneos/ ─────────────────────────────────────────────────────────
@torneos_bp.route('/', methods=['POST'])
def crear():
    err = _org()
    if err: return err
    data = request.get_json() or {}
    if not data.get('nombre') or not data.get('deporte'):
        return jsonify({'error': 'nombre y deporte son obligatorios'}), 400

    t = Torneo(
        nombre       = data['nombre'],
        deporte      = data['deporte'],
        modalidad    = data.get('modalidad', 'Liga'),
        inscripcion  = data.get('inscripcion', 0),
        direccion    = data.get('direccion', ''),
        fecha_inicio = _pd(data.get('fecha_inicio')),
        fecha_fin    = _pd(data.get('fecha_fin')),
        estado       = data.get('estado', 'Iniciado'),
        descripcion  = data.get('descripcion', ''),
        web_url      = data.get('web_url', ''),
        imagen_url   = data.get('imagen_url', ''),
    )
    db.session.add(t)
    db.session.commit()
    return jsonify(t.to_dict()), 201


# ── PUT /api/torneos/<id> ──────────────────────────────────────────────────────
@torneos_bp.route('/<int:tid>', methods=['PUT'])
def editar(tid):
    err = _org()
    if err: return err
    t    = Torneo.query.get_or_404(tid)
    data = request.get_json() or {}
    for c in ('nombre','deporte','modalidad','inscripcion','direccion',
              'estado','descripcion','web_url','imagen_url'):
        if c in data:
            setattr(t, c, data[c])
    if 'fecha_inicio' in data: t.fecha_inicio = _pd(data['fecha_inicio'])
    if 'fecha_fin'    in data: t.fecha_fin    = _pd(data['fecha_fin'])
    db.session.commit()
    return jsonify(t.to_dict()), 200


# ── DELETE /api/torneos/<id> ───────────────────────────────────────────────────
@torneos_bp.route('/<int:tid>', methods=['DELETE'])
def eliminar(tid):
    if session.get('rol') != 'admin':
        return jsonify({'error': 'Sin permisos'}), 403
    t = Torneo.query.get_or_404(tid)
    db.session.delete(t)
    db.session.commit()
    return jsonify({'mensaje': 'Torneo eliminado'}), 200


def _pd(s):
    try: return date.fromisoformat(s) if s else None
    except: return None
