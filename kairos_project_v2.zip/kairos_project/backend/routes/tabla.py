from flask import Blueprint, jsonify, request
from models.partido import Partido
from models.equipo  import Equipo

tabla_bp = Blueprint('tabla', __name__)


# ── GET /api/tabla/<torneo_id> ────────────────────────────────────────────────
@tabla_bp.route('/<int:torneo_id>', methods=['GET'])
def tabla_posiciones(torneo_id):
    """
    Calcula la tabla de posiciones en tiempo real
    a partir de los partidos con estado='Finalizado'.

    Query params:
      ?grupo=A   → filtra por grupo (fase de grupos)
    """
    grupo = request.args.get('grupo')

    q = Equipo.query.filter_by(torneo_id=torneo_id, activo=True)
    if grupo:
        q = q.filter_by(grupo=grupo)
    equipos = q.all()

    partidos = Partido.query.filter_by(
        torneo_id=torneo_id,
        estado='Finalizado'
    ).all()

    # inicializar tabla
    stats = {
        e.id: {
            'pos':    0,
            'equipo_id': e.id,
            'equipo': e.nombre,
            'escudo': e.escudo_url,
            'grupo':  e.grupo,
            'PJ': 0, 'PG': 0, 'PE': 0, 'PP': 0,
            'GF': 0, 'GC': 0, 'DG': 0, 'PTS': 0,
        }
        for e in equipos
    }

    for p in partidos:
        lid, vid = p.equipo_local_id, p.equipo_visitante_id
        gl,  gv  = p.goles_local,     p.goles_visitante

        if lid not in stats or vid not in stats:
            continue

        # acumular goles
        stats[lid]['PJ'] += 1;  stats[lid]['GF'] += gl;  stats[lid]['GC'] += gv
        stats[vid]['PJ'] += 1;  stats[vid]['GF'] += gv;  stats[vid]['GC'] += gl

        if gl > gv:          # gana local
            stats[lid]['PG'] += 1;  stats[lid]['PTS'] += 3
            stats[vid]['PP'] += 1
        elif gl < gv:        # gana visitante
            stats[vid]['PG'] += 1;  stats[vid]['PTS'] += 3
            stats[lid]['PP'] += 1
        else:                # empate
            stats[lid]['PE'] += 1;  stats[lid]['PTS'] += 1
            stats[vid]['PE'] += 1;  stats[vid]['PTS'] += 1

    tabla = list(stats.values())
    for r in tabla:
        r['DG'] = r['GF'] - r['GC']

    # orden: puntos → diferencia → goles a favor → nombre
    tabla.sort(key=lambda r: (r['PTS'], r['DG'], r['GF']), reverse=True)
    for i, r in enumerate(tabla, 1):
        r['pos'] = i

    return jsonify(tabla), 200
