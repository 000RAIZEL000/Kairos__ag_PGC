from flask import Blueprint, request, jsonify, session
from models.usuario import Usuario
from extensions import db

auth_bp = Blueprint('auth', __name__)

# ── helpers ────────────────────────────────────────────────────────────────────
def login_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get('usuario_id'):
            return jsonify({'error': 'Autenticación requerida'}), 401
        return fn(*args, **kwargs)
    return wrapper

def admin_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if session.get('rol') != 'admin':
            return jsonify({'error': 'Se requiere rol admin'}), 403
        return fn(*args, **kwargs)
    return wrapper


# ── POST /api/auth/registro ────────────────────────────────────────────────────
@auth_bp.route('/registro', methods=['POST'])
def registro():
    data = request.get_json() or {}
    obligatorios = ('nombre', 'apellido', 'email', 'password')
    if not all(data.get(c) for c in obligatorios):
        return jsonify({'error': 'Faltan campos: nombre, apellido, email, password'}), 400

    if Usuario.query.filter_by(email=data['email']).first():
        return jsonify({'error': 'El correo ya está registrado'}), 409

    u = Usuario(
        nombre   = data['nombre'].strip(),
        apellido = data['apellido'].strip(),
        email    = data['email'].strip().lower(),
        telefono = data.get('telefono', ''),
        genero   = data.get('genero', ''),
        rol      = 'usuario',
    )
    u.set_password(data['password'])
    db.session.add(u)
    db.session.commit()
    return jsonify({'mensaje': '¡Registro exitoso!', 'usuario': u.to_dict()}), 201


# ── POST /api/auth/login ───────────────────────────────────────────────────────
@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    email    = data.get('email', '').strip().lower()
    password = data.get('password', '')

    u = Usuario.query.filter_by(email=email).first()
    if not u or not u.check_password(password):
        return jsonify({'error': 'Correo o contraseña incorrectos'}), 401
    if not u.activo:
        return jsonify({'error': 'Cuenta desactivada'}), 403

    session['usuario_id'] = u.id
    session['rol']        = u.rol
    session['nombre']     = u.nombre
    return jsonify({'mensaje': f'¡Bienvenido {u.nombre}!', 'usuario': u.to_dict()}), 200


# ── POST /api/auth/logout ──────────────────────────────────────────────────────
@auth_bp.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'mensaje': 'Sesión cerrada correctamente'}), 200


# ── GET /api/auth/me ───────────────────────────────────────────────────────────
@auth_bp.route('/me', methods=['GET'])
@login_required
def me():
    u = Usuario.query.get_or_404(session['usuario_id'])
    return jsonify(u.to_dict()), 200


# ── GET /api/auth/usuarios  (admin) ───────────────────────────────────────────
@auth_bp.route('/usuarios', methods=['GET'])
@login_required
@admin_required
def listar_usuarios():
    usuarios = Usuario.query.order_by(Usuario.creado_en.desc()).all()
    return jsonify([u.to_dict() for u in usuarios]), 200


# ── PUT /api/auth/usuarios/<id>  (admin) ──────────────────────────────────────
@auth_bp.route('/usuarios/<int:uid>', methods=['PUT'])
@login_required
@admin_required
def editar_usuario(uid):
    u    = Usuario.query.get_or_404(uid)
    data = request.get_json() or {}
    for campo in ('nombre', 'apellido', 'telefono', 'genero', 'rol', 'activo'):
        if campo in data:
            setattr(u, campo, data[campo])
    if data.get('password'):
        u.set_password(data['password'])
    db.session.commit()
    return jsonify(u.to_dict()), 200
