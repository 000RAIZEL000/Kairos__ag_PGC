from flask import Blueprint, request, jsonify, session
from models.jugador import Jugador
from extensions import db
from datetime import date

jugadores_bp = Blueprint('jugadores', __name__)

def _org():
    if session.get('rol') not in ('admin', 'organizador'):
        return jsonify({'error': 'Sin permisos'}), 403
    return None


# ── GET /api/jugadores/ ───────────────────────────────────────────────────────
@jugadores_bp.route('/', methods=['GET'])
def listar():
    q = Jugador.query
    if request.args.get('equipo_id'):
        q = q.filter_by(equipo_id=int(request.args['equipo_id']))
    if request.args.get('posicion'):
        q = q.filter_by(posicion=request.args['posicion'])
    return jsonify([j.to_dict() for j in q.order_by(Jugador.apellido).all()]), 200


# ── GET /api/jugadores/<id> ───────────────────────────────────────────────────
@jugadores_bp.route('/<int:jid>', methods=['GET'])
def detalle(jid):
    j = Jugador.query.get_or_404(jid)
    d = j.to_dict()
    d['estadisticas'] = {
        'goles':            j.goles.count(),
        'amarillas':        j.tarjetas.filter_by(tipo='Amarilla').count(),
        'rojas':            j.tarjetas.filter_by(tipo='Roja').count(),
        'partidos_jugados': j.apariciones.count(),
    }
    return jsonify(d), 200


# ── POST /api/jugadores/ ──────────────────────────────────────────────────────
@jugadores_bp.route('/', methods=['POST'])
def crear():
    err = _org()
    if err: return err
    data = request.get_json() or {}
    if not all(data.get(c) for c in ('nombre','apellido','equipo_id')):
        return jsonify({'error': 'nombre, apellido y equipo_id son obligatorios'}), 400

    j = Jugador(
        nombre          = data['nombre'].strip(),
        apellido        = data['apellido'].strip(),
        dni             = data.get('dni'),
        fecha_nac       = _pd(data.get('fecha_nac')),
        posicion        = data.get('posicion', ''),
        numero_camiseta = data.get('numero_camiseta'),
        foto_url        = data.get('foto_url', ''),
        equipo_id       = data['equipo_id'],
    )
    db.session.add(j)
    db.session.commit()
    return jsonify(j.to_dict()), 201


# ── PUT /api/jugadores/<id> ───────────────────────────────────────────────────
@jugadores_bp.route('/<int:jid>', methods=['PUT'])
def editar(jid):
    err = _org()
    if err: return err
    j    = Jugador.query.get_or_404(jid)
    data = request.get_json() or {}
    for c in ('nombre','apellido','dni','posicion','numero_camiseta','foto_url','activo','equipo_id'):
        if c in data: setattr(j, c, data[c])
    if 'fecha_nac' in data: j.fecha_nac = _pd(data['fecha_nac'])
    db.session.commit()
    return jsonify(j.to_dict()), 200


# ── DELETE /api/jugadores/<id> ────────────────────────────────────────────────
@jugadores_bp.route('/<int:jid>', methods=['DELETE'])
def eliminar(jid):
    if session.get('rol') != 'admin':
        return jsonify({'error': 'Sin permisos'}), 403
    j = Jugador.query.get_or_404(jid)
    db.session.delete(j)
    db.session.commit()
    return jsonify({'mensaje': 'Jugador eliminado'}), 200


def _pd(s):
    try: return date.fromisoformat(s) if s else None
    except: return None
