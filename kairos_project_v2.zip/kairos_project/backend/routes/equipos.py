from flask import Blueprint, request, jsonify, session
from models.equipo import Equipo
from extensions import db

equipos_bp = Blueprint('equipos', __name__)

def _org():
    if session.get('rol') not in ('admin', 'organizador'):
        return jsonify({'error': 'Sin permisos'}), 403
    return None


# ── GET /api/equipos/ ─────────────────────────────────────────────────────────
@equipos_bp.route('/', methods=['GET'])
def listar():
    q = Equipo.query
    if request.args.get('torneo_id'):
        q = q.filter_by(torneo_id=int(request.args['torneo_id']))
    if request.args.get('grupo'):
        q = q.filter_by(grupo=request.args['grupo'])
    return jsonify([e.to_dict() for e in q.order_by(Equipo.nombre).all()]), 200


# ── GET /api/equipos/<id> ─────────────────────────────────────────────────────
@equipos_bp.route('/<int:eid>', methods=['GET'])
def detalle(eid):
    e = Equipo.query.get_or_404(eid)
    d = e.to_dict()
    d['jugadores']         = [j.to_dict() for j in e.jugadores.filter_by(activo=True).all()]
    d['total_jugadores']   = e.jugadores.count()
    return jsonify(d), 200


# ── POST /api/equipos/ ────────────────────────────────────────────────────────
@equipos_bp.route('/', methods=['POST'])
def crear():
    err = _org()
    if err: return err
    data = request.get_json() or {}
    if not data.get('nombre') or not data.get('torneo_id'):
        return jsonify({'error': 'nombre y torneo_id son obligatorios'}), 400

    e = Equipo(
        nombre           = data['nombre'],
        torneo_id        = data['torneo_id'],
        escudo_url       = data.get('escudo_url', ''),
        color_principal  = data.get('color_principal', ''),
        color_secundario = data.get('color_secundario', ''),
        grupo            = data.get('grupo', ''),
    )
    db.session.add(e)
    db.session.commit()
    return jsonify(e.to_dict()), 201


# ── PUT /api/equipos/<id> ─────────────────────────────────────────────────────
@equipos_bp.route('/<int:eid>', methods=['PUT'])
def editar(eid):
    err = _org()
    if err: return err
    e    = Equipo.query.get_or_404(eid)
    data = request.get_json() or {}
    for c in ('nombre','escudo_url','color_principal','color_secundario','grupo','activo'):
        if c in data: setattr(e, c, data[c])
    db.session.commit()
    return jsonify(e.to_dict()), 200


# ── DELETE /api/equipos/<id> ──────────────────────────────────────────────────
@equipos_bp.route('/<int:eid>', methods=['DELETE'])
def eliminar(eid):
    if session.get('rol') != 'admin':
        return jsonify({'error': 'Sin permisos'}), 403
    e = Equipo.query.get_or_404(eid)
    db.session.delete(e)
    db.session.commit()
    return jsonify({'mensaje': 'Equipo eliminado'}), 200
