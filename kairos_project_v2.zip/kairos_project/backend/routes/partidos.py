from flask import Blueprint, request, jsonify, session
from models.partido import Partido, Gol, Tarjeta, JugadorPartido
from extensions import db
from datetime import datetime

partidos_bp = Blueprint('partidos', __name__)

def _org():
    if session.get('rol') not in ('admin', 'organizador'):
        return jsonify({'error': 'Sin permisos'}), 403
    return None


# ── GET /api/partidos/ ────────────────────────────────────────────────────────
@partidos_bp.route('/', methods=['GET'])
def listar():
    q = Partido.query
    if request.args.get('torneo_id'):
        q = q.filter_by(torneo_id=int(request.args['torneo_id']))
    if request.args.get('estado'):
        q = q.filter_by(estado=request.args['estado'])
    if request.args.get('jornada'):
        q = q.filter_by(jornada=int(request.args['jornada']))
    if request.args.get('equipo_id'):
        eid = int(request.args['equipo_id'])
        q = q.filter(
            (Partido.equipo_local_id == eid) | (Partido.equipo_visitante_id == eid)
        )
    partidos = q.order_by(Partido.fecha.asc()).all()
    return jsonify([p.to_dict() for p in partidos]), 200


# ── GET /api/partidos/<id> ────────────────────────────────────────────────────
@partidos_bp.route('/<int:pid>', methods=['GET'])
def detalle(pid):
    p = Partido.query.get_or_404(pid)
    d = p.to_dict()
    d['goles']    = [g.to_dict()  for g  in p.goles.all()]
    d['tarjetas'] = [t.to_dict()  for t  in p.tarjetas.all()]
    d['planilla'] = [jp.to_dict() for jp in p.planillas.all()]
    return jsonify(d), 200


# ── POST /api/partidos/ ───────────────────────────────────────────────────────
@partidos_bp.route('/', methods=['POST'])
def crear():
    err = _org()
    if err: return err
    data = request.get_json() or {}
    req  = ('torneo_id', 'equipo_local_id', 'equipo_visitante_id')
    if not all(data.get(c) for c in req):
        return jsonify({'error': f'Campos requeridos: {", ".join(req)}'}), 400

    p = Partido(
        torneo_id           = data['torneo_id'],
        equipo_local_id     = data['equipo_local_id'],
        equipo_visitante_id = data['equipo_visitante_id'],
        fecha               = _pdt(data.get('fecha')),
        cancha              = data.get('cancha', ''),
        jornada             = data.get('jornada'),
        fase                = data.get('fase', 'Fase de grupos'),
        arbitro             = data.get('arbitro', ''),
        estado              = data.get('estado', 'Pendiente'),
    )
    db.session.add(p)
    db.session.commit()
    return jsonify(p.to_dict()), 201


# ── PUT /api/partidos/<id>/resultado ─────────────────────────────────────────
@partidos_bp.route('/<int:pid>/resultado', methods=['PUT'])
def actualizar_resultado(pid):
    err = _org()
    if err: return err
    p    = Partido.query.get_or_404(pid)
    data = request.get_json() or {}
    p.goles_local     = data.get('goles_local',     p.goles_local)
    p.goles_visitante = data.get('goles_visitante',  p.goles_visitante)
    p.estado          = data.get('estado',           p.estado)
    p.observaciones   = data.get('observaciones',    p.observaciones)
    db.session.commit()
    return jsonify(p.to_dict()), 200


# ── PUT /api/partidos/<id> ────────────────────────────────────────────────────
@partidos_bp.route('/<int:pid>', methods=['PUT'])
def editar(pid):
    err = _org()
    if err: return err
    p    = Partido.query.get_or_404(pid)
    data = request.get_json() or {}
    for c in ('cancha','jornada','fase','arbitro','estado','observaciones',
              'goles_local','goles_visitante'):
        if c in data: setattr(p, c, data[c])
    if 'fecha' in data: p.fecha = _pdt(data['fecha'])
    db.session.commit()
    return jsonify(p.to_dict()), 200


# ── POST /api/partidos/<id>/goles ─────────────────────────────────────────────
@partidos_bp.route('/<int:pid>/goles', methods=['POST'])
def agregar_gol(pid):
    err = _org()
    if err: return err
    data = request.get_json() or {}
    g = Gol(partido_id=pid, jugador_id=data['jugador_id'],
            equipo_id=data['equipo_id'], minuto=data.get('minuto'),
            tipo=data.get('tipo', 'Normal'))
    db.session.add(g)
    db.session.commit()
    return jsonify(g.to_dict()), 201


# ── POST /api/partidos/<id>/tarjetas ──────────────────────────────────────────
@partidos_bp.route('/<int:pid>/tarjetas', methods=['POST'])
def agregar_tarjeta(pid):
    err = _org()
    if err: return err
    data = request.get_json() or {}
    t = Tarjeta(partido_id=pid, jugador_id=data['jugador_id'],
                equipo_id=data['equipo_id'], tipo=data.get('tipo', 'Amarilla'),
                minuto=data.get('minuto'), motivo=data.get('motivo', ''))
    db.session.add(t)
    db.session.commit()
    return jsonify(t.to_dict()), 201


# ── POST /api/partidos/<id>/planilla ──────────────────────────────────────────
@partidos_bp.route('/<int:pid>/planilla', methods=['POST'])
def agregar_planilla(pid):
    err = _org()
    if err: return err
    data = request.get_json() or {}
    jp = JugadorPartido(partido_id=pid, jugador_id=data['jugador_id'],
                        equipo_id=data['equipo_id'], titular=data.get('titular', True),
                        minutos_jugados=data.get('minutos_jugados', 0))
    db.session.add(jp)
    db.session.commit()
    return jsonify(jp.to_dict()), 201


# ── DELETE /api/partidos/<id> ─────────────────────────────────────────────────
@partidos_bp.route('/<int:pid>', methods=['DELETE'])
def eliminar(pid):
    if session.get('rol') != 'admin':
        return jsonify({'error': 'Sin permisos'}), 403
    p = Partido.query.get_or_404(pid)
    db.session.delete(p)
    db.session.commit()
    return jsonify({'mensaje': 'Partido eliminado'}), 200


def _pdt(s):
    try: return datetime.fromisoformat(s) if s else None
    except: return None
