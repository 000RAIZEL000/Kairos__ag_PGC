import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY          = os.getenv('SECRET_KEY', 'kairos_ag_secret_2024')
    SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URL', 'sqlite:///kairos.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JSON_SORT_KEYS      = False

class DevelopmentConfig(Config):
    DEBUG = True

class ProductionConfig(Config):
    DEBUG = False
    # Railway/Render inyectan postgres://, SQLAlchemy necesita postgresql://
    db_url = os.getenv('DATABASE_URL', '')
    if db_url.startswith('postgres://'):
        SQLALCHEMY_DATABASE_URI = db_url.replace('postgres://', 'postgresql://', 1)

config = {
    'development': DevelopmentConfig,
    'production':  ProductionConfig,
    'default':     DevelopmentConfig
}
