from extensions import db
from datetime import datetime


class Torneo(db.Model):
    __tablename__ = 'torneos'

    id           = db.Column(db.Integer,     primary_key=True)
    nombre       = db.Column(db.String(150), nullable=False)
    deporte      = db.Column(db.String(80),  nullable=False)          # Fútbol 8 - Varones
    modalidad    = db.Column(db.String(50),  default='Liga')          # Liga | Copa | Grupos+Eliminatorias
    inscripcion  = db.Column(db.Float,       default=0)
    direccion    = db.Column(db.String(200), default='')
    fecha_inicio = db.Column(db.Date,        nullable=True)
    fecha_fin    = db.Column(db.Date,        nullable=True)
    estado       = db.Column(db.String(30),  default='Iniciado')      # Iniciado | Finalizado | Suspendido
    descripcion  = db.Column(db.Text,        default='')
    web_url      = db.Column(db.String(200), default='')
    imagen_url   = db.Column(db.String(200), default='')
    creado_en    = db.Column(db.DateTime,    default=datetime.utcnow)

    # relaciones
    equipos  = db.relationship('Equipo',  back_populates='torneo', lazy='dynamic', cascade='all, delete-orphan')
    partidos = db.relationship('Partido', back_populates='torneo', lazy='dynamic', cascade='all, delete-orphan')

    def to_dict(self) -> dict:
        return {
            'id':           self.id,
            'nombre':       self.nombre,
            'deporte':      self.deporte,
            'modalidad':    self.modalidad,
            'inscripcion':  self.inscripcion,
            'direccion':    self.direccion,
            'fecha_inicio': self.fecha_inicio.isoformat() if self.fecha_inicio else None,
            'fecha_fin':    self.fecha_fin.isoformat()    if self.fecha_fin    else None,
            'estado':       self.estado,
            'descripcion':  self.descripcion,
            'web_url':      self.web_url,
            'imagen_url':   self.imagen_url,
            'creado_en':    self.creado_en.isoformat(),
        }

    def __repr__(self):
        return f'<Torneo {self.nombre}>'
