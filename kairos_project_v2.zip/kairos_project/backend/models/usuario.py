from extensions import db
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime


class Usuario(db.Model):
    __tablename__ = 'usuarios'

    id            = db.Column(db.Integer,     primary_key=True)
    nombre        = db.Column(db.String(80),  nullable=False)
    apellido      = db.Column(db.String(80),  nullable=False)
    email         = db.Column(db.String(120), unique=True, nullable=False)
    telefono      = db.Column(db.String(20),  default='')
    genero        = db.Column(db.String(20),  default='')
    password_hash = db.Column(db.String(256), nullable=False)
    rol           = db.Column(db.String(20),  default='usuario')   # admin | organizador | usuario
    activo        = db.Column(db.Boolean,     default=True)
    creado_en     = db.Column(db.DateTime,    default=datetime.utcnow)

    # relaciones
    equipos_dirigidos = db.relationship('Equipo', back_populates='director_tecnico', lazy='dynamic')

    # ── métodos ────────────────────────────────────────────────────────────────
    def set_password(self, password: str):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)

    def to_dict(self) -> dict:
        return {
            'id':        self.id,
            'nombre':    self.nombre,
            'apellido':  self.apellido,
            'email':     self.email,
            'telefono':  self.telefono,
            'genero':    self.genero,
            'rol':       self.rol,
            'activo':    self.activo,
            'creado_en': self.creado_en.isoformat(),
        }

    def __repr__(self):
        return f'<Usuario {self.email}>'
