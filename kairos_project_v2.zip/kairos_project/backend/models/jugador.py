from extensions import db
from datetime import datetime


class Jugador(db.Model):
    __tablename__ = 'jugadores'

    id              = db.Column(db.Integer,     primary_key=True)
    nombre          = db.Column(db.String(80),  nullable=False)
    apellido        = db.Column(db.String(80),  nullable=False)
    dni             = db.Column(db.String(20),  unique=True, nullable=True)
    fecha_nac       = db.Column(db.Date,        nullable=True)
    posicion        = db.Column(db.String(40),  default='')   # Arquero | Defensa | Mediocampista | Delantero
    numero_camiseta = db.Column(db.Integer,     nullable=True)
    foto_url        = db.Column(db.String(200), default='')
    equipo_id       = db.Column(db.Integer,     db.ForeignKey('equipos.id'), nullable=False)
    activo          = db.Column(db.Boolean,     default=True)
    creado_en       = db.Column(db.DateTime,    default=datetime.utcnow)

    # relaciones
    equipo      = db.relationship('Equipo',        back_populates='jugadores')
    goles       = db.relationship('Gol',           back_populates='jugador', lazy='dynamic')
    tarjetas    = db.relationship('Tarjeta',        back_populates='jugador', lazy='dynamic')
    apariciones = db.relationship('JugadorPartido', back_populates='jugador', lazy='dynamic')

    def to_dict(self) -> dict:
        return {
            'id':               self.id,
            'nombre':           self.nombre,
            'apellido':         self.apellido,
            'nombre_completo':  f'{self.nombre} {self.apellido}',
            'dni':              self.dni,
            'fecha_nac':        self.fecha_nac.isoformat() if self.fecha_nac else None,
            'posicion':         self.posicion,
            'numero_camiseta':  self.numero_camiseta,
            'foto_url':         self.foto_url,
            'equipo_id':        self.equipo_id,
            'activo':           self.activo,
        }

    def __repr__(self):
        return f'<Jugador {self.nombre} {self.apellido}>'
