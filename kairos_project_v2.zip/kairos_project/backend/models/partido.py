from extensions import db
from datetime import datetime


class Partido(db.Model):
    __tablename__ = 'partidos'

    id                  = db.Column(db.Integer,     primary_key=True)
    torneo_id           = db.Column(db.Integer,     db.ForeignKey('torneos.id'),  nullable=False)
    equipo_local_id     = db.Column(db.Integer,     db.ForeignKey('equipos.id'),  nullable=False)
    equipo_visitante_id = db.Column(db.Integer,     db.ForeignKey('equipos.id'),  nullable=False)
    fecha               = db.Column(db.DateTime,    nullable=True)
    cancha              = db.Column(db.String(150), default='')
    jornada             = db.Column(db.Integer,     nullable=True)
    fase                = db.Column(db.String(50),  default='Fase de grupos')   # Fase de grupos | Cuartos | Semifinal | Final
    goles_local         = db.Column(db.Integer,     default=0)
    goles_visitante     = db.Column(db.Integer,     default=0)
    estado              = db.Column(db.String(20),  default='Pendiente')         # Pendiente | En curso | Finalizado | Suspendido
    arbitro             = db.Column(db.String(100), default='')
    observaciones       = db.Column(db.Text,        default='')
    creado_en           = db.Column(db.DateTime,    default=datetime.utcnow)

    # relaciones
    torneo             = db.relationship('Torneo',  back_populates='partidos')
    equipo_local       = db.relationship('Equipo',  foreign_keys=[equipo_local_id],     back_populates='partidos_local')
    equipo_visitante   = db.relationship('Equipo',  foreign_keys=[equipo_visitante_id],  back_populates='partidos_visitante')
    goles              = db.relationship('Gol',           back_populates='partido', lazy='dynamic', cascade='all, delete-orphan')
    tarjetas           = db.relationship('Tarjeta',        back_populates='partido', lazy='dynamic', cascade='all, delete-orphan')
    planillas          = db.relationship('JugadorPartido', back_populates='partido', lazy='dynamic', cascade='all, delete-orphan')

    def to_dict(self) -> dict:
        return {
            'id':                  self.id,
            'torneo_id':           self.torneo_id,
            'equipo_local_id':     self.equipo_local_id,
            'equipo_local':        self.equipo_local.nombre       if self.equipo_local     else None,
            'equipo_visitante_id': self.equipo_visitante_id,
            'equipo_visitante':    self.equipo_visitante.nombre   if self.equipo_visitante else None,
            'fecha':               self.fecha.isoformat()         if self.fecha            else None,
            'cancha':              self.cancha,
            'jornada':             self.jornada,
            'fase':                self.fase,
            'goles_local':         self.goles_local,
            'goles_visitante':     self.goles_visitante,
            'resultado':           f'{self.goles_local} - {self.goles_visitante}',
            'estado':              self.estado,
            'arbitro':             self.arbitro,
            'observaciones':       self.observaciones,
        }

    def __repr__(self):
        return f'<Partido {self.equipo_local_id} vs {self.equipo_visitante_id}>'


# ─────────────────────────────────────────────────────────────────────────────

class Gol(db.Model):
    __tablename__ = 'goles'

    id         = db.Column(db.Integer,    primary_key=True)
    partido_id = db.Column(db.Integer,    db.ForeignKey('partidos.id'),  nullable=False)
    jugador_id = db.Column(db.Integer,    db.ForeignKey('jugadores.id'), nullable=False)
    equipo_id  = db.Column(db.Integer,    db.ForeignKey('equipos.id'),   nullable=False)
    minuto     = db.Column(db.Integer,    nullable=True)
    tipo       = db.Column(db.String(20), default='Normal')   # Normal | Penal | En Contra | Tiro Libre

    partido = db.relationship('Partido', back_populates='goles')
    jugador = db.relationship('Jugador', back_populates='goles')

    def to_dict(self) -> dict:
        return {
            'id':         self.id,
            'partido_id': self.partido_id,
            'jugador_id': self.jugador_id,
            'jugador':    f'{self.jugador.nombre} {self.jugador.apellido}' if self.jugador else None,
            'equipo_id':  self.equipo_id,
            'minuto':     self.minuto,
            'tipo':       self.tipo,
        }


class Tarjeta(db.Model):
    __tablename__ = 'tarjetas'

    id         = db.Column(db.Integer,    primary_key=True)
    partido_id = db.Column(db.Integer,    db.ForeignKey('partidos.id'),  nullable=False)
    jugador_id = db.Column(db.Integer,    db.ForeignKey('jugadores.id'), nullable=False)
    equipo_id  = db.Column(db.Integer,    db.ForeignKey('equipos.id'),   nullable=False)
    tipo       = db.Column(db.String(10), nullable=False)   # Amarilla | Roja | Azul
    minuto     = db.Column(db.Integer,    nullable=True)
    motivo     = db.Column(db.String(200),default='')

    partido = db.relationship('Partido', back_populates='tarjetas')
    jugador = db.relationship('Jugador', back_populates='tarjetas')

    def to_dict(self) -> dict:
        return {
            'id':         self.id,
            'partido_id': self.partido_id,
            'jugador_id': self.jugador_id,
            'jugador':    f'{self.jugador.nombre} {self.jugador.apellido}' if self.jugador else None,
            'equipo_id':  self.equipo_id,
            'tipo':       self.tipo,
            'minuto':     self.minuto,
            'motivo':     self.motivo,
        }


class JugadorPartido(db.Model):
    """Planilla / alineación por partido."""
    __tablename__ = 'jugador_partido'

    id              = db.Column(db.Integer, primary_key=True)
    partido_id      = db.Column(db.Integer, db.ForeignKey('partidos.id'),  nullable=False)
    jugador_id      = db.Column(db.Integer, db.ForeignKey('jugadores.id'), nullable=False)
    equipo_id       = db.Column(db.Integer, db.ForeignKey('equipos.id'),   nullable=False)
    titular         = db.Column(db.Boolean, default=True)
    minutos_jugados = db.Column(db.Integer, default=0)

    partido = db.relationship('Partido', back_populates='planillas')
    jugador = db.relationship('Jugador', back_populates='apariciones')

    def to_dict(self) -> dict:
        return {
            'id':               self.id,
            'partido_id':       self.partido_id,
            'jugador_id':       self.jugador_id,
            'jugador':          f'{self.jugador.nombre} {self.jugador.apellido}' if self.jugador else None,
            'equipo_id':        self.equipo_id,
            'titular':          self.titular,
            'minutos_jugados':  self.minutos_jugados,
        }
