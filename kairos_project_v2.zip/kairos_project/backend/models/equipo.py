from extensions import db
from datetime import datetime


class Equipo(db.Model):
    __tablename__ = 'equipos'

    id                  = db.Column(db.Integer,     primary_key=True)
    nombre              = db.Column(db.String(100), nullable=False)
    torneo_id           = db.Column(db.Integer,     db.ForeignKey('torneos.id'),  nullable=False)
    director_tecnico_id = db.Column(db.Integer,     db.ForeignKey('usuarios.id'), nullable=True)
    escudo_url          = db.Column(db.String(200), default='')
    color_principal     = db.Column(db.String(20),  default='')
    color_secundario    = db.Column(db.String(20),  default='')
    grupo               = db.Column(db.String(10),  default='')   # A, B, C…
    activo              = db.Column(db.Boolean,     default=True)
    creado_en           = db.Column(db.DateTime,    default=datetime.utcnow)

    # relaciones
    torneo             = db.relationship('Torneo',  back_populates='equipos')
    director_tecnico   = db.relationship('Usuario', back_populates='equipos_dirigidos')
    jugadores          = db.relationship('Jugador', back_populates='equipo',              lazy='dynamic', cascade='all, delete-orphan')
    partidos_local     = db.relationship('Partido', foreign_keys='Partido.equipo_local_id',     back_populates='equipo_local')
    partidos_visitante = db.relationship('Partido', foreign_keys='Partido.equipo_visitante_id', back_populates='equipo_visitante')

    def to_dict(self) -> dict:
        return {
            'id':               self.id,
            'nombre':           self.nombre,
            'torneo_id':        self.torneo_id,
            'escudo_url':       self.escudo_url,
            'color_principal':  self.color_principal,
            'color_secundario': self.color_secundario,
            'grupo':            self.grupo,
            'activo':           self.activo,
            'creado_en':        self.creado_en.isoformat(),
        }

    def __repr__(self):
        return f'<Equipo {self.nombre}>'
