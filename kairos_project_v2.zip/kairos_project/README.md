# 🏆 Kairos AG – Sistema de Torneos

## Estructura
```
kairos_project/
├── backend/
│   ├── app.py            ← punto de entrada
│   ├── config.py         ← configuración dev/prod
│   ├── extensions.py     ← SQLAlchemy, Migrate, CORS
│   ├── requirements.txt
│   ├── .env              ← variables de entorno
│   ├── models/
│   │   ├── usuario.py
│   │   ├── torneo.py
│   │   ├── equipo.py
│   │   ├── jugador.py
│   │   └── partido.py    ← Partido, Gol, Tarjeta, JugadorPartido
│   └── routes/
│       ├── auth.py
│       ├── torneos.py
│       ├── equipos.py
│       ├── jugadores.py
│       ├── partidos.py
│       ├── tabla.py
│       └── estadisticas.py
└── frontend/
    ├── index.html
    ├── js/api.js          ← cliente HTTP listo para usar
    └── css/estilos.css
```

## ▶ Arrancar el backend (desarrollo)

```bash
cd backend
pip install -r requirements.txt
python app.py
```

API disponible en: **http://localhost:5000**

Usuario admin por defecto:
- Email: `admin@kairos.com`
- Contraseña: `admin123`

## 📡 Endpoints principales

| Método | URL | Descripción |
|--------|-----|-------------|
| POST | /api/auth/login | Iniciar sesión |
| POST | /api/auth/registro | Crear cuenta |
| GET  | /api/torneos/ | Listar torneos |
| GET  | /api/torneos/1 | Detalle torneo |
| POST | /api/torneos/ | Crear torneo |
| GET  | /api/equipos/?torneo_id=1 | Equipos del torneo |
| GET  | /api/jugadores/?equipo_id=1 | Jugadores del equipo |
| GET  | /api/partidos/?torneo_id=1 | Fixture del torneo |
| PUT  | /api/partidos/1/resultado | Cargar resultado |
| GET  | /api/tabla/1 | Tabla de posiciones |
| GET  | /api/estadisticas/goleadores/1 | Ranking goleadores |

## 🌐 Deploy en Railway (gratis)

1. Subí la carpeta a GitHub
2. En railway.app → New Project → Deploy from GitHub
3. Variables de entorno a configurar:
   - `SECRET_KEY` = (cualquier string largo)
   - `ADMIN_PASSWORD` = tu contraseña
4. Railway genera la URL pública automáticamente
