/**
 * api.js — cliente HTTP para el backend Kairos AG
 * Todas las funciones retornan Promise<data|Error>
 */

const API_BASE = 'http://localhost:5000/api';

// ── helper interno ────────────────────────────────────────────────────────────
async function req(method, path, body = null) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',   // envía cookies de sesión
  };
  if (body) opts.body = JSON.stringify(body);
  const res  = await fetch(API_BASE + path, opts);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Error del servidor');
  return data;
}

// ── AUTH ──────────────────────────────────────────────────────────────────────
export const auth = {
  login:    (email, password)       => req('POST', '/auth/login',    { email, password }),
  logout:   ()                      => req('POST', '/auth/logout'),
  registro: (datos)                 => req('POST', '/auth/registro',  datos),
  me:       ()                      => req('GET',  '/auth/me'),
  usuarios: ()                      => req('GET',  '/auth/usuarios'),
};

// ── TORNEOS ───────────────────────────────────────────────────────────────────
export const torneos = {
  listar:  (params = {})  => req('GET',    '/torneos/?' + new URLSearchParams(params)),
  detalle: (id)           => req('GET',    `/torneos/${id}`),
  crear:   (datos)        => req('POST',   '/torneos/',   datos),
  editar:  (id, datos)    => req('PUT',    `/torneos/${id}`, datos),
  eliminar:(id)           => req('DELETE', `/torneos/${id}`),
};

// ── EQUIPOS ───────────────────────────────────────────────────────────────────
export const equipos = {
  listar:  (params = {})  => req('GET',    '/equipos/?' + new URLSearchParams(params)),
  detalle: (id)           => req('GET',    `/equipos/${id}`),
  crear:   (datos)        => req('POST',   '/equipos/',   datos),
  editar:  (id, datos)    => req('PUT',    `/equipos/${id}`, datos),
  eliminar:(id)           => req('DELETE', `/equipos/${id}`),
};

// ── JUGADORES ─────────────────────────────────────────────────────────────────
export const jugadores = {
  listar:  (params = {})  => req('GET',    '/jugadores/?' + new URLSearchParams(params)),
  detalle: (id)           => req('GET',    `/jugadores/${id}`),
  crear:   (datos)        => req('POST',   '/jugadores/', datos),
  editar:  (id, datos)    => req('PUT',    `/jugadores/${id}`, datos),
  eliminar:(id)           => req('DELETE', `/jugadores/${id}`),
};

// ── PARTIDOS ──────────────────────────────────────────────────────────────────
export const partidos = {
  listar:    (params = {}) => req('GET',  '/partidos/?' + new URLSearchParams(params)),
  detalle:   (id)          => req('GET',  `/partidos/${id}`),
  crear:     (datos)       => req('POST', '/partidos/',   datos),
  editar:    (id, datos)   => req('PUT',  `/partidos/${id}`, datos),
  resultado: (id, datos)   => req('PUT',  `/partidos/${id}/resultado`, datos),
  gol:       (id, datos)   => req('POST', `/partidos/${id}/goles`,    datos),
  tarjeta:   (id, datos)   => req('POST', `/partidos/${id}/tarjetas`, datos),
  planilla:  (id, datos)   => req('POST', `/partidos/${id}/planilla`, datos),
};

// ── TABLA ─────────────────────────────────────────────────────────────────────
export const tabla = {
  posiciones: (torneoId, grupo = '') =>
    req('GET', `/tabla/${torneoId}` + (grupo ? `?grupo=${grupo}` : '')),
};

// ── ESTADÍSTICAS ──────────────────────────────────────────────────────────────
export const estadisticas = {
  torneo:     (id)         => req('GET', `/estadisticas/torneo/${id}`),
  goleadores: (id, lim=10) => req('GET', `/estadisticas/goleadores/${id}?limite=${lim}`),
  tarjetas:   (id, lim=10) => req('GET', `/estadisticas/tarjetas/${id}?limite=${lim}`),
  jugador:    (id)         => req('GET', `/estadisticas/jugador/${id}`),
  equipo:     (id)         => req('GET', `/estadisticas/equipo/${id}`),
};
